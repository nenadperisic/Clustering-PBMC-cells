from sklearn.cluster import KMeans
from yellowbrick.cluster import KElbowVisualizer
import pandas as pd
from sklearn.cluster import AgglomerativeClustering

# Instantiate the clustering model and visualizer
model = KMeans()
visualizer = KElbowVisualizer(model, k=(7,24))

df = pd.read_csv("preprocess.csv")
print(df.shape)

genes = df.iloc[:, 0]
genesT = genes.values
residual = df.iloc[:, 1:]
# print(residual.shape)
residualT = residual.transpose()
print(residualT.shape)
df = residual.values

# df = df[0:100]
# # print(df)

visualizer.fit(df)    # Fit the data to the visualizer
visualizer.poof()    # Draw/show/poof the data