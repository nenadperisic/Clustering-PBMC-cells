import pandas as pd
import nltk
import re
import collections
import numpy as np
from sklearn import datasets
from sklearn.cluster import AgglomerativeClustering
from sklearn.cluster import DBSCAN
from sklearn.preprocessing import StandardScaler
from sklearn import metrics
from sklearn.metrics import pairwise_distances

def dbscan(df, genesT):
	scaler = StandardScaler()
	tmp = df
	scaler.fit(df)

	df = scaler.transform(df)
	
	eps = 10
	min_samples = 12

	mdl = DBSCAN(eps=eps, min_samples=min_samples)
	mdl.fit(df)

	clusters = mdl.labels_
	clustersNum = collections.Counter(clusters)

	with open("klasterovani_geni_dbscan.txt", "w") as f:
		for i in clusters:
			f.write(str(int(i)) + "\n")

	for x in clustersNum:
		if (x == -1):
			print("Outliers : {} " . format(clustersNum[x]))
	else:
		print("Cluster {}: " . format(x), "{} " . format(clustersNum[x]))


	# ----------
	dictionary = {'-':[], '0':[]}
	with open("klasterovani_geni_dbscan.txt", "r") as f:
		lines = f.readlines()
		i = 0
		for l in lines:
			# dictionary[l[0]].append(genesT[i])
			dictionary[l[0]].append(i)
			i += 1

	for key, value in dictionary.items():
		if key == '-':
			with open("outliers.csv", "w") as f:
				for i in range(1, 4306):
					f.write("," + str(i))
				f.write("\n")

				for i in range(len(value)):
					f.write(str(genesT[i]) + ",")
					for j in range(tmp.shape[1]):
						if j == tmp.shape[1]-1:
							f.write(str(tmp[i][j]))
						else:
							f.write(str(tmp[i][j]) + ",")
					f.write("\n")

		if key == '0':
			with open("good_genes_dbscan.csv", "w") as f:
				for i in range(1, 4306):
					f.write("," + str(i))
				f.write("\n")

				for i in range(len(value)):
					f.write(str(genesT[i]) + ",")
					for j in range(tmp.shape[1]):
						if j == tmp.shape[1]-1:
							f.write(str(tmp[i][j]))
						else:
							f.write(str(tmp[i][j]) + ",")
					f.write("\n")
	
	# ----------


	score = metrics.silhouette_score(df, clusters, metric='euclidean')
	print("Quality: " + str(score))



def main():

	df = pd.read_csv("preprocess.csv")
	# df = pd.read_csv("outliers.csv")
	# df = pd.read_csv("good_genes_dbscan.csv")
	print(df.shape)

	genes = df.iloc[:, 0]
	genesT = genes.values

	residual = df.iloc[:, 1:]

	df = residual.values
	print(df.shape)
	# df = df[50:550]

	dbscan(df, genesT)


if __name__ == '__main__':
	main()