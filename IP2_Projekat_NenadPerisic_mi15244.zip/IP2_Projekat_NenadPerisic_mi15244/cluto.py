import pandas as pd
import nltk
import re
import collections
import numpy as np
from scipy.cluster.hierarchy import dendrogram, linkage
from sklearn import datasets
import matplotlib.pyplot as plt
from sklearn.cluster import KMeans
from minisom import MiniSom
from sklearn.cluster import AgglomerativeClustering
from sklearn.cluster import DBSCAN
from sklearn.preprocessing import StandardScaler
from sklearn.neighbors import LocalOutlierFactor

def main():

	df = pd.read_csv("preprocess.csv")
	print(df.shape)

	genes = df.iloc[:, 0]
	genesT = genes.values

	residual = df.iloc[:, 1:]

	# df = residual.values
	residualT = residual.transpose()
	# df = residualT.values

	# pravljenje ulazne matrice za program vcluster
    with open("data.mat", "w") as f:
		f.write(str(df.shape[0]) + " " + str(df.shape[1]) + "\n")
		for i in range(df.shape[0]):
			for j in range(df.shape[1]):
				if (j == 4305):
					f.write(str(df[i][j]))
				else:
					f.write(str(df[i][j]) + " ")
			f.write("\n")


	# upisivanje u fajl klastera i gena koji mu pripadaju a koji su rezultat rada cluto programa za gene
	dictionary = {'0':[], '1':[], '2':[], '3':[], '4':[], '5':[], '6':[]}
	with open("data.mat.clustering.7", "r") as f:
		lines = f.readlines()
		i = 0
		for l in lines:
			dictionary[l[0]].append(genesT[i])
			i += 1
		
	
	with open("klasterovani_geni_cluto.txt", "w") as f:
		for key, value in dictionary.items():
			f.write(str(key) + "\n")
			for gene in value:
				f.write(str(gene) + ", ")
			f.write("\n")



if __name__ == "__main__":
	main()