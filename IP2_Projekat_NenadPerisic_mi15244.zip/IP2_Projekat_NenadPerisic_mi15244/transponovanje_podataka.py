import pandas as pd
import nltk
import re
import collections
import numpy as np
from scipy.cluster.hierarchy import dendrogram
from sklearn import datasets
import matplotlib.pyplot as plt
from sklearn.cluster import KMeans
from minisom import MiniSom
from sklearn.cluster import AgglomerativeClustering
from sklearn.cluster import DBSCAN
from sklearn.preprocessing import StandardScaler
from sklearn.neighbors import LocalOutlierFactor


def main():


    df = pd.read_csv("preprocess.csv")
    print(df.shape)

    genes = df.iloc[:, 0]
    genesT = genes.values

    residual = df.iloc[:, 1:]
    print(residual.shape)
    # residualT = residual.transpose()
    residualT = np.array(residual)
    residualT = residualT.transpose()
    print(residualT.shape)


    with open("data_transposed.mat", "w") as f:
    	f.write(str(residualT.shape[0]) + " " + str(residualT.shape[1]) + "\n")
    	for i in range(4305):
    		# f.write(str(genesP[i]))
    		for j in range(20308):
    			if (j == 20307):
    				f.write(str(residualT[i][j]))
    			else:
    				f.write(str(residualT[i][j]) + " ")
    		f.write("\n")



if __name__ == "__main__":
    main()
