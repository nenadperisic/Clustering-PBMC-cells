import pandas as pd
import nltk
import re
import collections
import numpy as np
from scipy.cluster.hierarchy import dendrogram
from sklearn import datasets
import matplotlib.pyplot as plt
from sklearn.cluster import KMeans
from minisom import MiniSom
from sklearn.cluster import AgglomerativeClustering
from sklearn.cluster import DBSCAN
from sklearn.preprocessing import StandardScaler
from sklearn.neighbors import LocalOutlierFactor


def preprocess(data, genes):
	a = 0
	b = 0
	positions = []
	for position, row in enumerate(data):
		if (all(value == 0 for value in row)):
			a += 1
			positions.append(position)
		else:
			b += 1

	print(a)
	print(b)
	data1 = np.delete(data, positions, 0)
	genes1 = np.delete(genes, positions)

	return data1, genes1

def main():

	df = pd.read_csv("001_Melanoma_Cell_Line_csv.csv")
	print(df.shape)

	genes = df.iloc[:, 0]
	genesT = genes.values
	# genesT = ['hg38_A1BG' 'hg38_A1BG-AS1'...'hg38_ZZEF1']

	residual = df.iloc[:, 1:]
	# residualT = residual.transpose()

	df = residual.values

	dfP, genesP = preprocess(df, genesT)
	print(dfP.shape)

	# pravimo csv fajl od pretprocesiranih podatka
	with open("preprocess.csv", "w") as f:
		f.write(",")
		for i in range(4305):
		    if i == 4304:
		        f.write(i + "\n")
		    else:
		        f.write(i + ",")
    
		for i in range(dfP.shape[0]):
			for j in range(dfP.shape[1]):
				if (j == 4304):
					f.write(str(dfP[i][j]))
				else:
					f.write(str(dfP[i][j]) + " ")
			f.write("\n")


if __name__ == "__main__":
	main()
