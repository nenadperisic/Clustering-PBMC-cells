import sys
import pandas as pd
import nltk
import re
import collections
import numpy as np
from scipy.cluster.hierarchy import dendrogram, linkage
from sklearn import datasets
import matplotlib.pyplot as plt
from sklearn.cluster import KMeans
from minisom import MiniSom
from sklearn.cluster import AgglomerativeClustering
from sklearn.cluster import DBSCAN
from sklearn.preprocessing import StandardScaler
from sklearn.neighbors import LocalOutlierFactor
from sklearn import metrics
from sklearn.metrics import pairwise_distances


def kmeans(df, genes, nb_clusters):
	kmeans = KMeans(n_clusters=nb_clusters, n_init=15).fit(df)
	clusters = kmeans.labels_

	with open("klasterovani_geni_k_sredina.txt", "w") as f:
		for i in clusters:
			f.write(str(int(i)) + "\n")

	clustersNum = collections.Counter(clusters)
	for c in clustersNum:
		print("Cluster {}: " . format(c), "{}" . format(clustersNum[c]))

	
	score = metrics.silhouette_score(df, clusters, metric='euclidean')
	print("Quality: " + str(score))


def som(df):
	mdl = MiniSom(27, 27, 20308)
	mdl.random_weights_init(df.T)
	mdl.train_batch(df.T, num_iteration=100)

	plt.pcolor(mdl.distance_map().T)
	plt.show()


def plot_dendrogram(df):

	linkage_matrix = linkage(df, 'ward')
	figure = plt.figure(figsize=(7.5, 5))
	dendrogram(linkage_matrix, color_threshold=10000)

	plt.title('Hierarchical Clustering Dendrogram (Ward)')
	plt.xlabel('sample index')
	plt.ylabel('distance')
	plt.tight_layout()


def agglomerativeClustering(df, nb_clusters):
	
	mdl = AgglomerativeClustering(n_clusters=nb_clusters, affinity='euclidean', linkage='ward')
	fitted = mdl.fit(df)
	clusters = fitted.labels_
	with open("klasterovani_geni_hijerarhijsko_v1.txt", "w") as f:
		for i in clusters:
			f.write(str(int(i)) + "\n")

	clustersNum = collections.Counter(clusters)

	for i in clustersNum:
			print('Cluster {}: '.format(i), " Size: {}".format(clustersNum[i]))

	
	score = metrics.silhouette_score(df, clusters, metric='euclidean')
	print("Quality: " + str(score))
	


def dbscan(df, genesT):
	scaler = StandardScaler()
	tmp = df
	scaler.fit(df)

	df = scaler.transform(df)
	
	eps = 10
	min_samples = 12

	mdl = DBSCAN(eps=eps, min_samples=min_samples)
	mdl.fit(df)

	clusters = mdl.labels_
	clustersNum = collections.Counter(clusters)

	with open("klasterovani_geni_dbscan.txt", "w") as f:
		for i in clusters:
			f.write(str(int(i)) + "\n")

	for x in clustersNum:
		if (x == -1):
			print("Outliers : {} " . format(clustersNum[x]))
		else:
			print("Cluster {}: " . format(x), "{} " . format(clustersNum[x]))


	score = metrics.silhouette_score(df, clusters, metric='euclidean')
	print("Quality: " + str(score))


def main():

	df = pd.read_csv("preprocess.csv")
	# df = pd.read_csv("outliers.csv") # pazi
	# df = pd.read_csv("good_genes_dbscan.csv")
	print(df.shape)

	genes = df.iloc[:, 0]
	genesT = genes.values

	residual = df.iloc[:, 1:]

	df = residual.values
	print(df.shape)
	# df = df[50:550]


	if sys.argv[1] == "kmeans":
		kmeans(df, genesT, 19)

	elif sys.argv[1] == "dbscan":
		dbscan(df, genesT)

	elif sys.argv[1] == "agglomerative":
		agglomerativeClustering(df, nb_clusters=14)
	
	elif sys.argv[1] == "som":
		som(df)
	
	# plot_dendrogram(df)
	# plt.show()


if __name__ == "__main__":
	main()

